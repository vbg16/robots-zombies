# Paleta — zumbi ex-mecânico (proposta)

- Sombras: #1B2A3A
- Pele escura: #425C50
- Pele: #778B72
- Pele luz: #A4AD8B
- Tecido escuro: #544F42
- Macacão terroso: #79705B
- Tecido luz: #A79A76
- Ferrugem: #C95F43
- Olhos âmbar: #F4B656
- Botas: #303B3D e #586363

Direção frontal; 48x64 px; pixel art nativa. Arte proposta, revisão visual e integração pendentes.
